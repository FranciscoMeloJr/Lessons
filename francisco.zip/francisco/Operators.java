package tp6305.francisco;

public enum Operators {
	equal, greater, or, and, less;
}