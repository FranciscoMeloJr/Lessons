package tp6305.francisco;

public enum Variables {
	Vars1,
	Vars2,
	Vars3,
	size,
	Vartrian,
	zero,
	first,
	second,
	third,
	Vars1s2,
	Vars2s3,
	Vars1s3;
}